# Bank-Customer-Churn-Model
Customer Churn prediction means knowing which customers are likely to leave or unsubscribe from your service.
